﻿# --------------------------------------------------------------------------------------------

from .models import *
from .customer_intelligence_client import CustomerIntelligenceClient

__all__ = [
    'CustomerIntelligenceEvent',
    'CustomerIntelligenceClient'
]
